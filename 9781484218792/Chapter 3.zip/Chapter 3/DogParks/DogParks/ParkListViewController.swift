//
//  ParkListViewController.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa

class ParkListViewController: NSViewController {

    @IBOutlet weak var newParkButton: NSButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let style = NSMutableParagraphStyle()
        style.alignment = .Center
        
        newParkButton.attributedTitle = NSAttributedString(string: "New Park", attributes: [NSForegroundColorAttributeName: NSColor.whiteColor(), NSParagraphStyleAttributeName: style, NSFontAttributeName: NSFont(name: "Helvetica Neue", size: 20)!])
    }
    
    override func awakeFromNib() {
        if self.view.layer != nil {
            let color : CGColorRef = CGColorCreateFromHex(0xF5F7F7)
            self.view.layer?.backgroundColor = color
        }
    }
    
}
