//
//  DetailViewController.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa

class DetailViewController: NSViewController {
    
    @IBOutlet weak var parkImagesCollection: NSCollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // don't forget to set identifier of collectionViewItem
        // from interface builder
        let itemProtoType = self.storyboard?.instantiateControllerWithIdentifier("collectionViewItem") as! NSCollectionViewItem
        self.parkImagesCollection.itemPrototype = itemProtoType
    }
    
    override func awakeFromNib() {
        if self.view.layer != nil {
            let color : CGColorRef = CGColorCreateFromHex(0xFFFFFF)
            self.view.layer?.backgroundColor = color
        }
    }
    
}
