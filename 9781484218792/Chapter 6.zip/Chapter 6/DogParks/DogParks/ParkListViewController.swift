//
//  ParkListViewController.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa

protocol ParkListViewControllerDelegate: class {
    func parkListViewController(viewController: ParkListViewController, selectedPark: Park?) -> Void
}

class ParkListViewController: NSViewController {

    @IBOutlet weak var newParkButton: NSButton!
    weak var delegate: ParkListViewControllerDelegate? = nil
    
    let api = API()
    dynamic var parks: [Park] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let style = NSMutableParagraphStyle()
        style.alignment = .Center
        
        newParkButton.attributedTitle = NSAttributedString(string: "New Park", attributes: [NSForegroundColorAttributeName: NSColor.whiteColor(), NSParagraphStyleAttributeName: style, NSFontAttributeName: NSFont(name: "Helvetica Neue", size: 20)!])
        
        api.fetchParks { [unowned self] (parks) -> Void in
            dispatch_async(dispatch_get_main_queue()) {
                self.parks = parks
            }
        }
    }
    
    override func awakeFromNib() {
        if self.view.layer != nil {
            let color : CGColorRef = CGColorCreateFromHex(0xF5F7F7)
            self.view.layer?.backgroundColor = color
        }
    }
    
    
    @IBAction func selectPark(sender: AnyObject) {
        let selectedPark = parks[sender.selectedRow]
        delegate?.parkListViewController(self, selectedPark: selectedPark)
    }
    
}
