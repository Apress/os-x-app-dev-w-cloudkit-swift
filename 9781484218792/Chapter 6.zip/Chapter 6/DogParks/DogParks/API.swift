//
//  API.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa
import CloudKit

class API {
    let publicDB = CKContainer.defaultContainer().publicCloudDatabase
    var parks: [Park] = []
    var parkImages: [ParkImage] = []
    
    func fetchParks(completionHandler: [Park] -> Void) {
        let parksPredicate = NSPredicate(value: true)
        let query = CKQuery(recordType: "Parks", predicate: parksPredicate)
        
        publicDB.performQuery(query, inZoneWithID: nil) { [unowned self] (results, error) -> Void in
            
            if error != nil {
                print("Error: \(error)")
            } else {
                for result in results! {
                    var thumbnailUrl: NSURL? = nil
                    if let thumbnail = result["thumbnail"] as? CKAsset {
                        thumbnailUrl = thumbnail.fileURL
                    }
                    let park = Park(
                        recordID: result["recordID"] as! CKRecordID,
                        name: result["name"] as! String,
                        overview: result["overview"] as! String,
                        location: result["location"] as! String,
                        isFenced: result["isFenced"] as! Bool,
                        hasFreshWater: result["hasFreshWater"] as! Bool,
                        allowsOffleash: result["hasFreshWater"] as! Bool,
                        thumbnailUrl: thumbnailUrl
                    )
                    self.parks.append(park)
                }
                completionHandler(self.parks)
            }
        }
    }
    
    func fetchParkImages(parkRecordID: CKRecordID, completionHandler: [ParkImage] -> Void) {
        let reference = CKReference(recordID: parkRecordID, action: CKReferenceAction.DeleteSelf)
        let pred = NSPredicate(format: "park == %@", reference)
        let sort = NSSortDescriptor(key: "creationDate", ascending: true)
        let query = CKQuery(recordType: "ParkImages", predicate: pred)
        query.sortDescriptors = [sort]
        
        parkImages = []
        
        publicDB.performQuery(query, inZoneWithID: nil) { [unowned self] (results, error) -> Void in
            if error != nil {
                print(error!.localizedDescription)
            } else {
                for result in results! {
                    var thumbnailUrl: NSURL? = nil
                    if let thumbnail = result["thumbnail"] as? CKAsset {
                        thumbnailUrl = thumbnail.fileURL
                    }
                    var imageUrl: NSURL? = nil
                    if let image = result["image"] as? CKAsset {
                        imageUrl = image.fileURL
                    }
                    let parkImage = ParkImage(recordID: result["recordID"] as! CKRecordID, thumbnailUrl: thumbnailUrl, imageURL: imageUrl)
                    self.parkImages.append(parkImage)
                }
                completionHandler(self.parkImages)
            }
        }
    }
}