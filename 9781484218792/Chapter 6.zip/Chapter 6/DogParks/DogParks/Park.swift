//
//  Park.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa
import CloudKit

class Park: NSObject {
    var recordID: CKRecordID
    var name: String
    var overview: String
    var location: String
    var isFenced: Bool
    var hasFreshWater: Bool
    var allowsOffleash: Bool
    var thumbnail: NSImage?
    
    init(recordID: CKRecordID, name: String, overview: String, location: String, isFenced: Bool, hasFreshWater: Bool, allowsOffleash: Bool, thumbnailUrl: NSURL?) {
        
        self.recordID = recordID
        self.name = name
        self.overview = overview
        self.location = location
        self.isFenced = isFenced
        self.hasFreshWater = hasFreshWater
        self.allowsOffleash = allowsOffleash
        
        super.init()
        
        if thumbnailUrl == nil {
            self.thumbnail = NSImage(named: "DefaultParkIcon")!
        } else {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0)) {
                if let imageData = NSData(contentsOfFile: (thumbnailUrl?.path)!) {
                self.thumbnail = NSImage(data: imageData)!
                }
            }
        }
    }
}