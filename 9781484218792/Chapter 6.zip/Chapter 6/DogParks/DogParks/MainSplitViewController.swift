//
//  MainSplitViewController.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa

class MainSplitViewController: NSSplitViewController {
    
    var masterViewController: ParkListViewController {
        let masterItem = splitViewItems[0]
        return masterItem.viewController as! ParkListViewController
    }
    
    var detailViewController: DetailViewController {
        let detailItem = splitViewItems[1]
        return detailItem.viewController as! DetailViewController
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
        
        masterViewController.delegate = self
    }
    
}

extension MainSplitViewController: ParkListViewControllerDelegate {
    
    func parkListViewController(viewController: ParkListViewController, selectedPark: Park?) {
        detailViewController.loadPark(selectedPark)
    }
}