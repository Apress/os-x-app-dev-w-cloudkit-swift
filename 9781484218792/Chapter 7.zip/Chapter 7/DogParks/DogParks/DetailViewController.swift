//
//  DetailViewController.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa

class DetailViewController: NSViewController {
    
    @IBOutlet weak var parkImagesCollection: NSCollectionView!
    @IBOutlet var imagesArrayController: NSArrayController!
    
    let api = API()
    private dynamic var parkImages: [ParkImage] = []
    
    private dynamic var park: Park? = nil
    var parkIndex: Int? = nil
    weak var delegate: ParkListViewControllerDelegate? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // don't forget to set identifier of collectionViewItem
        // from interface builder
        let itemProtoType = self.storyboard?.instantiateControllerWithIdentifier("collectionViewItem") as! NSCollectionViewItem
        self.parkImagesCollection.itemPrototype = itemProtoType
    }
    
    func loadPark(park: Park?, index: Int) {
        self.park = park
        self.parkIndex = index
        
        parkImages = []
        
        if self.park != nil {
            api.fetchParkImages((self.park?.recordID)!, completionHandler: { [unowned self] (parkImages) -> Void in
                if parkImages.count > 0 {
                    dispatch_async(dispatch_get_main_queue()) {
                        self.imagesArrayController.addObjects(parkImages)
                    }
                }
            })
        }
    }
    
    override func awakeFromNib() {
        if self.view.layer != nil {
            let color : CGColorRef = CGColorCreateFromHex(0xFFFFFF)
            self.view.layer?.backgroundColor = color
        }
    }
    
    @IBAction func savePark(sender: AnyObject) {
        if let park = self.park {
            api.updatePark(park) { [unowned self] (updatedPark) -> Void in
                dispatch_async(dispatch_get_main_queue()) {
                    self.park = updatedPark
                }
            }
        }
    }
    
    @IBAction func addImages(sender: AnyObject) {
        let openPanel = NSOpenPanel()
        openPanel.allowsMultipleSelection = true
        openPanel.canChooseDirectories = false
        openPanel.canCreateDirectories = false
        openPanel.canChooseFiles = true
        openPanel.allowedFileTypes = NSImage.imageUnfilteredTypes()
        openPanel.beginWithCompletionHandler { (result) -> Void in
            if result == NSFileHandlingPanelOKButton {
                self.api.saveParkImages((self.park?.recordID)!, imageUrls: openPanel.URLs, completionHandler: { (parkImages) -> Void in
                    dispatch_async(dispatch_get_main_queue()) {
                        self.imagesArrayController.addObjects(parkImages)
                    }
                })
            }
        }
    }
    
    @IBAction func deletePark(sender: AnyObject) {
        api.deletePark((park?.recordID)!) { [unowned self] (error) -> Void in
            if error != nil {
                print(error!.localizedDescription)
            } else {
                dispatch_async(dispatch_get_main_queue()) {
                    self.parkImages.removeAll()
                    self.park = nil
                    self.delegate?.deletePark(self.parkIndex!)
                    self.parkIndex = nil
                }
            }
        }
    }
    
    @IBAction func deleteImages(sender: AnyObject) {
        let selectedParkImages = parkImagesCollection.selectionIndexes
        var imagesToDelete: [ParkImage]? = []
        selectedParkImages.enumerateIndexesUsingBlock { [unowned self] (index, _) -> Void in
            imagesToDelete?.append(self.parkImages[index])
        }
        api.deleteParkImages(imagesToDelete!) {
            (error) -> Void in
            if error != nil {
                print(error!.localizedDescription)
            } else {
                dispatch_async(dispatch_get_main_queue()) {
                    self.imagesArrayController.removeObjectsAtArrangedObjectIndexes(selectedParkImages)
                }
            }
        }
    }
    
}
