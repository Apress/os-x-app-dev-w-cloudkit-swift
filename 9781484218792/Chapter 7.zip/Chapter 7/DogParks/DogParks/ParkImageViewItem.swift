//
//  ParkImageViewItem.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa

class ParkImageViewItem: NSCollectionViewItem {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
    override var selected: Bool {
        didSet {
            if self.selected {
                self.view.layer?.borderColor = NSColor.orangeColor().CGColor
                self.view.layer?.borderWidth = 3
                self.view.layer?.cornerRadius = 10
            } else {
                self.view.layer?.borderColor = NSColor.clearColor().CGColor
                self.view.layer?.borderWidth = 0
                self.view.layer?.cornerRadius = 0
            }
        }
    }
    
}
