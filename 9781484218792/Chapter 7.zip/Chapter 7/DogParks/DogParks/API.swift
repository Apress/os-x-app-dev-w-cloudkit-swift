//
//  API.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa
import CloudKit

class API {
    let publicDB = CKContainer.defaultContainer().publicCloudDatabase
    var parks: [Park] = []
    var parkImages: [ParkImage] = []
    
    func fetchParks(completionHandler: [Park] -> Void) {
        let parksPredicate = NSPredicate(value: true)
        let query = CKQuery(recordType: "Parks", predicate: parksPredicate)
        
        publicDB.performQuery(query, inZoneWithID: nil) { [unowned self] (results, error) -> Void in
            
            if error != nil {
                print("Error: \(error)")
            } else {
                for result in results! {
                    let park = self.convertCKRecordToPark(result)
                    self.parks.append(park)
                }
                completionHandler(self.parks)
            }
        }
    }
    
    func fetchParkImages(parkRecordID: CKRecordID, completionHandler: [ParkImage] -> Void) {
        let reference = CKReference(recordID: parkRecordID, action: CKReferenceAction.DeleteSelf)
        let pred = NSPredicate(format: "park == %@", reference)
        let sort = NSSortDescriptor(key: "creationDate", ascending: true)
        let query = CKQuery(recordType: "ParkImages", predicate: pred)
        query.sortDescriptors = [sort]
        
        parkImages = []
        
        publicDB.performQuery(query, inZoneWithID: nil) { [unowned self] (results, error) -> Void in
            if error != nil {
                print(error!.localizedDescription)
            } else {
                for result in results! {
                    self.parkImages.append(self.convertCKRecordToParkImage(result))
                }
                completionHandler(self.parkImages)
            }
        }
    }
    
    func createPark(completionHandler: Park -> Void) {
        let newParkRecord = CKRecord(recordType: "Parks")
        newParkRecord["name"] = "New Park"
        
        publicDB.saveRecord(newParkRecord) { (newPark, error) -> Void in
            if error != nil {
                print(error!.localizedDescription)
            } else {
                completionHandler(self.convertCKRecordToPark(newPark!))
            }
        }
    }
    
    func updatePark(park: Park, completionHandler: Park -> Void) {
        // Get any changes for the park from the server
        publicDB.fetchRecordWithID(park.recordID) { (parkRecord, error) -> Void in
            if error != nil {
                print(error!.localizedDescription)
            } else {
                // Currently just overriding as we are the only ones using this app.
                parkRecord!["name"] = park.name
                parkRecord!["location"] = park.location
                parkRecord!["overview"] = park.overview
                parkRecord!["isFenced"] = park.isFenced
                parkRecord!["hasFreshWater"] = park.hasFreshWater
                parkRecord!["allowsOffleash"] = park.allowsOffleash
                
                // Save update back to the server
                self.publicDB.saveRecord(parkRecord!, completionHandler: { (parkRecord, error) -> Void in
                    if error != nil {
                        print(error!.localizedDescription)
                    } else {
                        completionHandler(self.convertCKRecordToPark(parkRecord!))
                    }
                })
            }
        }
    }
    
    func deletePark(parkRecordID: CKRecordID, completionHandler: NSError? -> Void) {
        publicDB.deleteRecordWithID(parkRecordID) {
            (deletedRecordID, error) -> Void in
            completionHandler(error)
        }
    }
    
    func saveParkImages(parkRecordID: CKRecordID, imageUrls: [NSURL], completionHandler: [ParkImage] -> Void) {
        
        var tempThumbnailFiles = [String]()
        var imageRecordsToUpload = [CKRecord]()
        
        for imageUrl in imageUrls {
            // Get file name
            let originalFileName = imageUrl.URLByDeletingPathExtension!.lastPathComponent!
            let thumbnailFileName = "/tmp/\(originalFileName)_90x90.jpg"
            tempThumbnailFiles.append(thumbnailFileName)
            
            // Create a thumbnail from the original image
            let originalImage = NSImage(contentsOfURL: imageUrl)
            let thumbnailImage = originalImage?.makeThumbnail(90, 90)
            
            // Save the thumbnail to a file
            thumbnailImage?.saveTo(thumbnailFileName)
            
            let record = CKRecord(recordType: "ParkImages")
            record["park"] = CKReference(recordID: parkRecordID, action: .DeleteSelf)
            record["image"] = CKAsset(fileURL: imageUrl)
            record["thumbnail"] = CKAsset(fileURL: NSURL(fileURLWithPath: thumbnailFileName))
            imageRecordsToUpload.append(record)
        }
        
        let uploadOperation = CKModifyRecordsOperation(recordsToSave: imageRecordsToUpload, recordIDsToDelete: nil)
        uploadOperation.atomic = false
        uploadOperation.database = publicDB
        
        uploadOperation.modifyRecordsCompletionBlock = {
            (savedRecords: [CKRecord]?, deletedRecords: [CKRecordID]?, operationError: NSError?) -> Void in
            guard operationError == nil else {
                print(operationError!.localizedDescription)
                return
            }
            if let records = savedRecords {
                var imagesUploaded = [ParkImage]()
                for parkImageRecord in records {
                    // Create a new ParkImage record and append it to array of imagesUploaded
                    imagesUploaded.append(self.convertCKRecordToParkImage(parkImageRecord))
                }
                
                // Now that we know our file was uploaded delete temp local files
                for tempThumbnailFile in tempThumbnailFiles {
                    do {
                        try NSFileManager.defaultManager().removeItemAtPath(tempThumbnailFile)
                    } catch _ {
                        print("Couldn't delete file: \(tempThumbnailFile)")
                    }
                }
                completionHandler(imagesUploaded)
            }
        }
        NSOperationQueue().addOperation(uploadOperation)
    }
    
    func deleteParkImages(imagesToDelete: [ParkImage], completionHandler: NSError? -> Void) {
        var imageRecordIDsToDelete = [CKRecordID]()
        
        for image in imagesToDelete {
            imageRecordIDsToDelete.append(image.recordID)
        }
        
        let deleteOperation = CKModifyRecordsOperation(recordsToSave: nil, recordIDsToDelete: imageRecordIDsToDelete)
        deleteOperation.atomic = false
        deleteOperation.database = publicDB
        
        deleteOperation.modifyRecordsCompletionBlock = {
            (savedRecords: [CKRecord]?, deletedRecords: [CKRecordID]?, operationError: NSError?) -> Void in
            completionHandler(operationError)
        }
        
        NSOperationQueue().addOperation(deleteOperation)
    }
    
    private func convertCKRecordToPark(parkRecord: CKRecord) -> Park {
        
        var thumbnailUrl: NSURL? = nil
        if let thumbnail = parkRecord["thumbnail"] as? CKAsset {
            thumbnailUrl = thumbnail.fileURL
        }
        let savedPark = Park(
            recordID: parkRecord["recordID"] as! CKRecordID,
            name: parkRecord["name"] as? String ?? "",
            overview: parkRecord["overview"] as? String ?? "",
            location: parkRecord["location"] as? String ?? "",
            isFenced: parkRecord["isFenced"] as? Bool ?? false,
            hasFreshWater: parkRecord["hasFreshWater"] as? Bool ?? false,
            allowsOffleash: parkRecord["allowsOffleash"] as? Bool ?? false,
            thumbnailUrl: thumbnailUrl
        )
        return savedPark
    }
    
    private func convertCKRecordToParkImage(parkImageRecord: CKRecord) -> ParkImage {
        var thumbnailUrl: NSURL? = nil
        if let thumbnail = parkImageRecord["thumbnail"] as? CKAsset {
            thumbnailUrl = thumbnail.fileURL
        }
        var imageUrl: NSURL? = nil
        if let image = parkImageRecord["image"] as? CKAsset {
            imageUrl = image.fileURL
        }
        let parkImage = ParkImage(
            recordID: parkImageRecord["recordID"] as! CKRecordID,
            thumbnailUrl: thumbnailUrl,
            imageURL: imageUrl
        )
        return parkImage
    }
}