//
//  AppDelegate.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(aNotification: NSNotification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }


}

func CGColorCreateWithHexValues(red red: Int, green: Int, blue: Int) -> CGColor {
    assert(red >= 0 && red <= 255, "Invalid red component")
    assert(green >= 0 && green <= 255, "Invalid green component")
    assert(blue >= 0 && blue <= 255, "Invalid blue component")
    
    return CGColorCreateGenericRGB(CGFloat(red) / 255.0, CGFloat(green) / 255.0, CGFloat(blue) / 255.0, 1.0)
}

func CGColorCreateFromHex(netHex: Int) -> CGColor {
    return CGColorCreateWithHexValues(red: (netHex >> 16) & 0xff, green: (netHex >> 8) & 0xff, blue: netHex & 0xff)
}

