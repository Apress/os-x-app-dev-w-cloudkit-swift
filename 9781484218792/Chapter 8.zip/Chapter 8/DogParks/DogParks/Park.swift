//
//  Park.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa
import CloudKit

class Park: NSObject, NSCoding {
    var recordID: CKRecordID
    var name: String
    var overview: String
    var location: String
    var isFenced: Bool
    var hasFreshWater: Bool
    var allowsOffleash: Bool
    var thumbnail: NSImage?
    
    init(recordID: CKRecordID, name: String, overview: String, location: String, isFenced: Bool, hasFreshWater: Bool, allowsOffleash: Bool) {
        
        self.recordID = recordID
        self.name = name
        self.overview = overview
        self.location = location
        self.isFenced = isFenced
        self.hasFreshWater = hasFreshWater
        self.allowsOffleash = allowsOffleash
        
        super.init()
        
        self.thumbnail = NSImage(named: "DefaultParkIcon")!
        
    }
    
    required init(coder aDecoder: NSCoder) {
        let recordName = aDecoder.decodeObjectForKey("recordName") as! String
        self.recordID = CKRecordID(recordName: recordName)
        self.name = aDecoder.decodeObjectForKey("name") as! String
        self.overview = aDecoder.decodeObjectForKey("overview") as! String
        self.location = aDecoder.decodeObjectForKey("location") as! String
        self.isFenced = aDecoder.decodeBoolForKey("isFenced")
        self.hasFreshWater = aDecoder.decodeBoolForKey("hasFreshWater")
        self.allowsOffleash = aDecoder.decodeBoolForKey("allowsOffleash")
        super.init()
    }
    
    func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encodeObject(recordID.recordName, forKey: "recordName")
        aCoder.encodeObject(name, forKey: "name")
        aCoder.encodeObject(overview, forKey: "overview")
        aCoder.encodeObject(location, forKey: "location")
        aCoder.encodeBool(isFenced, forKey: "isFenced")
        aCoder.encodeBool(hasFreshWater, forKey: "hasFreshWater")
        aCoder.encodeBool(allowsOffleash, forKey: "allowsOffleash")
    }

}