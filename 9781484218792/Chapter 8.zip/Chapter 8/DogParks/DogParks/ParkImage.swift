//
//  ParkImage.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa
import CloudKit

class ParkImage: NSObject {
    var recordID: CKRecordID
    var thumbnail: NSImage?
    var imageURL: NSURL?
    var image: NSImage?
    
    init(recordID: CKRecordID, thumbnailUrl: NSURL?, imageURL: NSURL?) {
        self.recordID = recordID
        self.imageURL = imageURL
        
        super.init()
        
        if thumbnailUrl != nil {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0)) {
                if let imageData = NSData(contentsOfFile: (thumbnailUrl?.path)!) {
                    self.thumbnail = NSImage(data: imageData)!
                }
            }
        }
    }
}
