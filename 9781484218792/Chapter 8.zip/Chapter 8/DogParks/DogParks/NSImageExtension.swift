//
//  NSImageExtension.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa

extension NSImage {
    
    func makeThumbnail(width: CGFloat, _ height: CGFloat) -> NSImage {
        let thumbnail = NSImage(size: CGSizeMake(width, height))
        thumbnail.lockFocus()
        let context = NSGraphicsContext.currentContext()
        context?.imageInterpolation = .High
        self.drawInRect(NSMakeRect(0, 0, width, height), fromRect: NSMakeRect(0, 0, size.width, size.height), operation: .CompositeCopy, fraction: 1)
        thumbnail.unlockFocus()
        return thumbnail
    }
    
    func saveTo(filePath: String) {
        let bmpImageRep: NSBitmapImageRep = NSBitmapImageRep(data: TIFFRepresentation!)!
        addRepresentation(bmpImageRep)
        
        let data: NSData = bmpImageRep.representationUsingType(.NSJPEGFileType, properties: [:])!
        data.writeToFile(filePath, atomically: false)
    }
    
}
