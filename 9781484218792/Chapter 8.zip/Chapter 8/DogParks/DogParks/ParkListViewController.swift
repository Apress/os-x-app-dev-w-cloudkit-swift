//
//  ParkListViewController.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa

protocol ParkListViewControllerDelegate: class {
    func selectPark(selectedPark: Park?, index: Int) -> Void
    func deletePark(deletedParkIndex: Int) -> Void
}

class ParkListViewController: NSViewController {

    @IBOutlet var arrayController: NSArrayController!
    @IBOutlet weak var tableView: NSTableView!
    @IBOutlet weak var newParkButton: NSButton!
    weak var delegate: ParkListViewControllerDelegate? = nil
    
    let api = API()
    dynamic var parks: [Park] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let style = NSMutableParagraphStyle()
        style.alignment = .Center
        
        newParkButton.attributedTitle = NSAttributedString(string: "New Park", attributes: [NSForegroundColorAttributeName: NSColor.whiteColor(), NSParagraphStyleAttributeName: style, NSFontAttributeName: NSFont(name: "Helvetica Neue", size: 20)!])
        
        api.fetchParks { [unowned self] (parks) -> Void in
            dispatch_async(dispatch_get_main_queue()) {
                self.parks = parks
                self.loadThumbnails()
                self.persist()
            }
        }
    }
    
    override func awakeFromNib() {
        if self.view.layer != nil {
            let color : CGColorRef = CGColorCreateFromHex(0xF5F7F7)
            self.view.layer?.backgroundColor = color
        }
    }
    
    func cachePath() -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.CachesDirectory, .UserDomainMask, true)
        let path = paths[0].stringByAppendingString("/parks.cache")
        return path
    }
    
    func persist() {
        let data = NSMutableData()
        let archiver = NSKeyedArchiver(forWritingWithMutableData: data)
        archiver.encodeRootObject(parks)
        archiver.finishEncoding()
        data.writeToFile(cachePath(), atomically: true)
    }
    
    func loadCache() {
        let path = cachePath()
        if let data = NSData(contentsOfFile: path) where data.length > 0 {
            let decoder = NSKeyedUnarchiver(forReadingWithData: data)
            let object: AnyObject! = decoder.decodeObject()
            if object != nil {
                dispatch_async(dispatch_get_main_queue(), { [unowned self]() -> Void in
                    self.parks = object as! [Park]
                    self.loadThumbnails()
                })
            }
        }
    }
    
    func loadThumbnails() {
        for (index, park) in self.parks.enumerate() {
            api.loadParkThumbnail(park.recordID) { (photo) -> Void in
                dispatch_async(dispatch_get_main_queue()) {
                    if photo != nil {
                        self.parks[index].thumbnail = photo
                        self.tableView.reloadDataForRowIndexes(NSIndexSet(index: index), columnIndexes: NSIndexSet(index: 0))
                    }
                }
            }
        }
    }
    
    func deletePark(index: Int) {
        dispatch_async(dispatch_get_main_queue()) {
            self.arrayController.removeObjectAtArrangedObjectIndex(index)
//            self.tableView.deselectRow(index)
//            self.tableView.removeRowsAtIndexes(NSIndexSet(index: index), withAnimation: NSTableViewAnimationOptions.EffectFade)
//            self.parks.removeAtIndex(index)
        }
    }
    
    
    @IBAction func selectPark(sender: AnyObject) {
        //let selectedRow = sender.selectedRow
        //let selectedPark = parks[selectedRow]
        let selectedRow = arrayController.selectionIndex
        let selectedPark = arrayController.selectedObjects.first as! Park
        delegate?.selectPark(selectedPark, index: selectedRow)
    }
    
    @IBAction func createPark(sender: AnyObject) {
        api.createPark { [unowned self] (newPark) -> Void in
            dispatch_async(dispatch_get_main_queue()) {
                self.parks.append(newPark)
                self.tableView.selectRowIndexes(NSIndexSet(index: self.parks.endIndex - 1), byExtendingSelection: false)
                self.tableView.scrollRowToVisible(self.parks.endIndex-1)
                self.delegate?.selectPark(self.parks.last, index: self.parks.endIndex-1)
            }
            
        }
    }
    
}
