//
//  API.swift
//  DogParks
//
//  Created by Bruce Wade on 2016-02-02.
//  Copyright © 2016 Warply Designed Inc. All rights reserved.
//

import Cocoa
import CloudKit

class API {
    let publicDB = CKContainer.defaultContainer().publicCloudDatabase
    var parks: [Park] = []
    var parkImages: [ParkImage] = []
    
    func fetchParks(completionHandler: [Park] -> Void) {
        let parksPredicate = NSPredicate(value: true)
        let query = CKQuery(recordType: "Parks", predicate: parksPredicate)
        
        let queryOp = CKQueryOperation(query: query)
        queryOp.desiredKeys = ["name", "location", "overview", "isFenced", "hasFreshWater", "allowsOffleash"]
        runOperation(queryOp, completionHandler: completionHandler)
    }
    
    func runOperation(queryOp: CKQueryOperation, completionHandler: [Park] -> Void) {
        queryOp.queryCompletionBlock = { cursor, error in
            if self.isRetryableCKError(error) {
                let userInfo: NSDictionary = (error?.userInfo)!
                if let retryAfter = userInfo[CKErrorRetryAfterKey] as? NSNumber {
                    let delay = retryAfter.doubleValue * Double(NSEC_PER_SEC)
                    let time = dispatch_time(DISPATCH_TIME_NOW, Int64(delay))
                    dispatch_after(time, dispatch_get_main_queue()) {
                        self.runOperation(queryOp, completionHandler: completionHandler)
                    }
                    return
                }
            }
            self.queryFinished(cursor, error: error, completionHandler: completionHandler)
            if cursor != nil {
                self.queryNextCursor(cursor!, completionHandler: completionHandler)
            } else {
                completionHandler(self.parks)
            }
        }
        queryOp.recordFetchedBlock = { record in
            self.fetchedPark(record)
        }
        publicDB.addOperation(queryOp)
    }
    
    func queryFinished(cursor: CKQueryCursor!, error: NSError!, completionHandler: [Park] -> Void) {
        completionHandler(self.parks)
    }
    
    func queryNextCursor(cursor: CKQueryCursor, completionHandler: [Park] -> Void) {
        let queryOp = CKQueryOperation(cursor: cursor)
        runOperation(queryOp, completionHandler: completionHandler)
    }
    
    func fetchedPark(parkRecord: CKRecord) {
        var index = NSNotFound
        var park: Park!
        var isNewPark = true
        
        for (idx, value) in self.parks.enumerate() {
            if value.recordID == parkRecord.recordID {
                // Here we could check to see if the park pulled has been updated and update our list.
                // This is left for an exercise to the reader.
                index = idx
                park = value
                isNewPark = false
                break
            }
        }
        
        if index == NSNotFound {
            park = self.convertCKRecordToPark(parkRecord)
            self.parks.append(park)
            index = self.parks.count - 1
        }
    }
    
    func fetchParkImages(parkRecordID: CKRecordID, completionHandler: [ParkImage] -> Void) {
        let reference = CKReference(recordID: parkRecordID, action: CKReferenceAction.DeleteSelf)
        let pred = NSPredicate(format: "park == %@", reference)
        let sort = NSSortDescriptor(key: "creationDate", ascending: true)
        let query = CKQuery(recordType: "ParkImages", predicate: pred)
        query.sortDescriptors = [sort]
        
        parkImages = []
        
        publicDB.performQuery(query, inZoneWithID: nil) { [unowned self] (results, error) -> Void in
            if error != nil {
                print(error!.localizedDescription)
            } else {
                for result in results! {
                    self.parkImages.append(self.convertCKRecordToParkImage(result))
                }
                completionHandler(self.parkImages)
            }
        }
    }
    
    func createPark(completionHandler: Park -> Void) {
        let newParkRecord = CKRecord(recordType: "Parks")
        newParkRecord["name"] = "New Park"
        
        publicDB.saveRecord(newParkRecord) { (newPark, error) -> Void in
            if error != nil {
                print(error!.localizedDescription)
            } else {
                completionHandler(self.convertCKRecordToPark(newPark!))
            }
        }
    }
    
    func updatePark(park: Park, completionHandler: Park -> Void) {
        // Get any changes for the park from the server
        publicDB.fetchRecordWithID(park.recordID) { (parkRecord, error) -> Void in
            if error != nil {
                print(error!.localizedDescription)
            } else {
                // Currently just overriding as we are the only ones using this app.
                parkRecord!["name"] = park.name
                parkRecord!["location"] = park.location
                parkRecord!["overview"] = park.overview
                parkRecord!["isFenced"] = park.isFenced
                parkRecord!["hasFreshWater"] = park.hasFreshWater
                parkRecord!["allowsOffleash"] = park.allowsOffleash
                
                // Save update back to the server
                self.publicDB.saveRecord(parkRecord!, completionHandler: { (parkRecord, error) -> Void in
                    if error != nil {
                        print(error!.localizedDescription)
                    } else {
                        completionHandler(self.convertCKRecordToPark(parkRecord!))
                    }
                })
            }
        }
    }
    
    func deletePark(parkRecordID: CKRecordID, completionHandler: NSError? -> Void) {
        publicDB.deleteRecordWithID(parkRecordID) {
            (deletedRecordID, error) -> Void in
            completionHandler(error)
        }
    }
    
    func saveParkImages(parkRecordID: CKRecordID, imageUrls: [NSURL], completionHandler: [ParkImage] -> Void) {
        
        var tempThumbnailFiles = [String]()
        var imageRecordsToUpload = [CKRecord]()
        
        for imageUrl in imageUrls {
            // Get file name
            let originalFileName = imageUrl.URLByDeletingPathExtension!.lastPathComponent!
            let thumbnailFileName = "/tmp/\(originalFileName)_90x90.jpg"
            tempThumbnailFiles.append(thumbnailFileName)
            
            // Create a thumbnail from the original image
            let originalImage = NSImage(contentsOfURL: imageUrl)
            let thumbnailImage = originalImage?.makeThumbnail(90, 90)
            
            // Save the thumbnail to a file
            thumbnailImage?.saveTo(thumbnailFileName)
            
            let record = CKRecord(recordType: "ParkImages")
            record["park"] = CKReference(recordID: parkRecordID, action: .DeleteSelf)
            record["image"] = CKAsset(fileURL: imageUrl)
            record["thumbnail"] = CKAsset(fileURL: NSURL(fileURLWithPath: thumbnailFileName))
            imageRecordsToUpload.append(record)
        }
        
        let uploadOperation = CKModifyRecordsOperation(recordsToSave: imageRecordsToUpload, recordIDsToDelete: nil)
        uploadOperation.atomic = false
        uploadOperation.database = publicDB
        
        uploadOperation.modifyRecordsCompletionBlock = {
            (savedRecords: [CKRecord]?, deletedRecords: [CKRecordID]?, operationError: NSError?) -> Void in
            guard operationError == nil else {
                print(operationError!.localizedDescription)
                return
            }
            if let records = savedRecords {
                var imagesUploaded = [ParkImage]()
                for parkImageRecord in records {
                    // Create a new ParkImage record and append it to array of imagesUploaded
                    imagesUploaded.append(self.convertCKRecordToParkImage(parkImageRecord))
                }
                
                // Now that we know our file was uploaded delete temp local files
                for tempThumbnailFile in tempThumbnailFiles {
                    do {
                        try NSFileManager.defaultManager().removeItemAtPath(tempThumbnailFile)
                    } catch _ {
                        print("Couldn't delete file: \(tempThumbnailFile)")
                    }
                }
                completionHandler(imagesUploaded)
            }
        }
        NSOperationQueue().addOperation(uploadOperation)
    }
    
    func deleteParkImages(imagesToDelete: [ParkImage], completionHandler: NSError? -> Void) {
        var imageRecordIDsToDelete = [CKRecordID]()
        
        for image in imagesToDelete {
            imageRecordIDsToDelete.append(image.recordID)
        }
        
        let deleteOperation = CKModifyRecordsOperation(recordsToSave: nil, recordIDsToDelete: imageRecordIDsToDelete)
        deleteOperation.atomic = false
        deleteOperation.database = publicDB
        
        deleteOperation.modifyRecordsCompletionBlock = {
            (savedRecords: [CKRecord]?, deletedRecords: [CKRecordID]?, operationError: NSError?) -> Void in
            completionHandler(operationError)
        }
        
        NSOperationQueue().addOperation(deleteOperation)
    }
    
    func imageCachePath(recordID: CKRecordID) -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.CachesDirectory, .UserDomainMask, true)
        let path = paths[0].stringByAppendingString("/\(recordID.recordName)")
        return path
    }
    
    func loadParkThumbnail(parkRecordID: CKRecordID, completion: (photo: NSImage!) -> Void) {
        let backgroundQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0)
        dispatch_async(backgroundQueue) { () -> Void in
            let imagePath = self.imageCachePath(parkRecordID)
            if NSFileManager.defaultManager().fileExistsAtPath(imagePath) {
                let image = NSImage(contentsOfFile: imagePath)
                completion(photo: image)
            } else {
                let fetchOp = CKFetchRecordsOperation(recordIDs: [parkRecordID])
                fetchOp.desiredKeys = ["thumbnail"]
                fetchOp.fetchRecordsCompletionBlock = {
                    records, error in
                    self.processThumbnailAsset(parkRecordID, records: records, error: error, completionHandler: completion)
                }
                self.publicDB.addOperation(fetchOp)
            }
        }
    }
    
    func processThumbnailAsset(parkRecordID: CKRecordID, records: [NSObject: AnyObject]!, error: NSError!, completionHandler: (thumbnail: NSImage!) -> Void) {
        if error != nil {
            completionHandler(thumbnail: nil)
        }
        let updatedRecord = records[parkRecordID] as! CKRecord
        if let asset = updatedRecord.objectForKey("thumbnail") as? CKAsset {
            let url = asset.fileURL
            let thumbnail = NSImage(contentsOfFile: url.path!)
            do {
                try NSFileManager.defaultManager().copyItemAtPath(url.path!, toPath: imageCachePath(parkRecordID))
            } catch {
                print("There was an issue copying the image")
            }
            completionHandler(thumbnail: thumbnail)
        } else {
            completionHandler(thumbnail: nil)
        }
    }
    
    private func convertCKRecordToPark(parkRecord: CKRecord) -> Park {
        
        let savedPark = Park(
            recordID: parkRecord["recordID"] as! CKRecordID,
            name: parkRecord["name"] as? String ?? "",
            overview: parkRecord["overview"] as? String ?? "",
            location: parkRecord["location"] as? String ?? "",
            isFenced: parkRecord["isFenced"] as? Bool ?? false,
            hasFreshWater: parkRecord["hasFreshWater"] as? Bool ?? false,
            allowsOffleash: parkRecord["allowsOffleash"] as? Bool ?? false
        )
        return savedPark
    }
    
    private func convertCKRecordToParkImage(parkImageRecord: CKRecord) -> ParkImage {
        var thumbnailUrl: NSURL? = nil
        if let thumbnail = parkImageRecord["thumbnail"] as? CKAsset {
            thumbnailUrl = thumbnail.fileURL
        }
        var imageUrl: NSURL? = nil
        if let image = parkImageRecord["image"] as? CKAsset {
            imageUrl = image.fileURL
        }
        let parkImage = ParkImage(
            recordID: parkImageRecord["recordID"] as! CKRecordID,
            thumbnailUrl: thumbnailUrl,
            imageURL: imageUrl
        )
        return parkImage
    }
    
    private func isRetryableCKError(error: NSError?) -> Bool {
        var isRetryable = false
        if let error = error {
            let isErrorDomain = error.domain == CKErrorDomain
            let errorCode: Int = error.code
            let isUnavailable = errorCode == CKErrorCode.ServiceUnavailable.rawValue
            let isRateLimited = errorCode == CKErrorCode.RequestRateLimited.rawValue
            let errorCodeIsRetryable = isUnavailable || isRateLimited
            isRetryable = isErrorDomain && errorCodeIsRetryable
        }
        return isRetryable
    }
}